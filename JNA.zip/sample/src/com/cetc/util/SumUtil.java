package com.cetc.util;

import java.io.File;
import com.sun.jna.Library;
import com.sun.jna.Native;


public class SumUtil {

    public interface Sum extends Library {

        int sum(int x, int y);

        Sum INSTANCE = (Sum) Native.loadLibrary("sum", Sum.class);
    }

    static {
        File file = new File("C:\\MinGW\\bin\\sum.dll");
        System.load(file.getAbsolutePath());
    }

    public static void main(String[] args) {
        System.out.println("***************************");
        System.out.println(Sum.INSTANCE.sum(1,2));
        System.out.println("***************************");
    }
}
